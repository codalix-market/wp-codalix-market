<?php
/**
 * Items section
 *
 * * @package Codalix_Market
 * @since 1.0.0
 */

?>
<p><?php esc_html_e( 'Add Codalix Market themes & plugins using multiple OAuth tokens. This is especially useful when an item has been purchased on behalf of a third-party. This works similarly to the global OAuth Personal Token, but for individual items and additionally requires the Codalix Market item ID.', 'codalix-market' ); ?></p>

<p><?php esc_html_e( 'Warning: These tokens can be revoked by the account holder at any time.', 'codalix-market' ); ?></p>


