<?php
/**
 * OAuth section
 *
 * * @package Codalix_Market
 * @since 1.0.0
 */

?>

<p>
	<?php printf( esc_html__( 'This area enables WordPress Theme &amp; Plugin updates from Codalix Market. Read more about how this process works at %s.', 'codalix-market' ), '<a href="https://codalixmarket.cloud/market-plugin/" target="_blank">' . esc_html__( 'codalixmarket.cloud', 'codalix-market' ) . '</a>' ); ?>
</p>
<p>
	<?php esc_html_e( 'Please follow the steps below:', 'codalix-market' ); ?>
</p>
<ol>
	<li><?php printf( esc_html__( 'Generate an Codalix API Personal Token by %s.', 'codalix-market' ), '<a href="' . codalix_market()->admin()->get_generate_token_url() . '" target="_blank">' . esc_html__( 'clicking this link', 'codalix-market' ) . '</a>' ); ?></li>
	<li><?php esc_html_e( 'Name the token eg “My WordPress site”.', 'codalix-market' ); ?></li>
	<li><?php esc_html_e( 'Ensure the following permissions are enabled:', 'codalix-market' ); ?>
		<ul>
			<li><?php esc_html_e( 'View and search Codalix sites', 'codalix-market' ); ?></li>
			<li><?php esc_html_e( 'Download your purchased items', 'codalix-market' ); ?></li>
			<li><?php esc_html_e( 'List purchases you\'ve made', 'codalix-market' ); ?></li>
		</ul>
	</li>
	<li><?php esc_html_e( 'Copy the token into the box below.', 'codalix-market' ); ?></li>
	<li><?php esc_html_e( 'Click the "Save Changes" button.', 'codalix-market' ); ?></li>
	<li><?php esc_html_e( 'A list of purchased Themes &amp; Plugins from Codalix Market will appear.', 'codalix-market' ); ?></li>
</ol>


