<?php
/**
 * Token setting
 *
 * * @package Codalix_Market
 * @since 1.0.0
 */

?>
<input type="text" name="<?php echo esc_attr( codalix_market()->get_option_name() ); ?>[token]" class="widefat" value="<?php echo esc_html( codalix_market()->get_option( 'token' ) ); ?>" autocomplete="off">

<p class="description"><?php esc_html_e( 'Enter your Codalix API Personal Token.', 'codalix-market' ); ?></p>


