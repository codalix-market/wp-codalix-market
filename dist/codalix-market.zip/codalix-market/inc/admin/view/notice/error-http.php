<?php
/**
 * Error notice
 *
 * * @package Codalix_Market
 * @since 2.0.1
 */

?>
<div class="notice notice-error is-dismissible">
	<p><?php esc_html_e( 'Failed to connect to the Codalix API. Please contact the hosting providier with this message: "The Codalix Market WordPress plugin requires TLS version 1.2 or above, please confirm if this hosting account supports TLS version 1.2 and allows connections from WordPress to the host api.codalixmarket.cloud".', 'codalix-market' ); ?></p>
</div>


