<?php
/**
 * Success notice
 *
 * @package Codalix_Market
 * @since 1.0.0
 */

?>
<div class="notice notice-success is-dismissible">
	<p><?php esc_html_e( 'All Single Use OAuth Personal Tokens have been verified.', 'codalix-market' ); ?></p>
</div>


