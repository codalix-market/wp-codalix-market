<?php
/**
 * Themes panel partial
 *
 * @package Codalix_Market
 * @since 1.0.0
 */

$themes = codalix_market()->items()->themes( 'purchased' );

?>
<div id="themes" class="panel <?php echo empty( $themes ) ? 'hidden' : ''; ?>">
	<div class="codalix-market-blocks">
		<?php
		if ( ! empty( $themes ) ) {
			codalix_market_themes_column( 'active' );
			codalix_market_themes_column( 'installed' );
			codalix_market_themes_column( 'install' );
		}
		?>
	</div>
</div>


