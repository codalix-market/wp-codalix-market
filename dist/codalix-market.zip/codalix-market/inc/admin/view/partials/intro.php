<?php
/**
 * Intro partial
 *
 * @package Codalix_Market
 * @since 1.0.0
 */

?>
<div class="col">

	<h1 class="about-title"><img class="about-logo" src="<?php echo codalix_market()->get_plugin_url(); ?>images/codalix-market-logo.svg" alt="Codalix Market"><sup><?php echo esc_html( codalix_market()->get_version() ); ?></sup></h1>
	<p><?php esc_html_e( 'Welcome!', 'codalix-market' ); ?></p>
	<p><?php esc_html_e( 'This plugin can install WordPress themes and plugins purchased from CodaLix Market by connecting with the Codalix Market API using a secure OAuth personal token. Once your themes & plugins are installed WordPress will periodically check for updates, so keeping your items up to date is as simple as a few clicks.', 'codalix-market' ); ?></p>
	<p><strong><?php printf( esc_html__( 'Find out more at %1$scodalixmarket.cloud%2$s.', 'codalix-market' ), '<a href="https://codalixmarket.cloud/market-plugin/" target="_blank">', '</a>' ); ?></strong></p>
</div>


