<?php
/**
 * Plugins panel partial
 *
 * @package Codalix_Market
 * @since 1.0.0
 */

$plugins = codalix_market()->items()->plugins( 'purchased' );

?>
<div id="plugins" class="panel <?php echo empty( $plugins ) ? 'hidden' : ''; ?>">
	<div class="codalix-market-blocks">
		<?php
		if ( ! empty( $plugins ) ) {
			codalix_market_plugins_column( 'active' );
			codalix_market_plugins_column( 'installed' );
			codalix_market_plugins_column( 'install' );
		}
		?>
	</div>
</div>


