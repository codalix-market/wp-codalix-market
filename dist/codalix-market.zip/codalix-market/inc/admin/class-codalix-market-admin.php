<?php
/**
 * Admin UI class.
 *
 * @package Codalix_Market
 */

if ( ! class_exists( 'Codalix_Market_Admin' ) && class_exists( 'Codalix_Market' ) ) :

	/**
	 * Creates an admin page to save the Codalix API OAuth token.
	 *
	 * @class Codalix_Market_Admin
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	class Codalix_Market_Admin {

		/**
		 * Action nonce.
		 *
		 * @type string
		 */
		const AJAX_ACTION = 'codalix_market';

		/**
		 * The single class instance.
		 *
		 * @since 1.0.0
		 * @access private
		 *
		 * @var object
		 */
		private static $_instance = null;

		/**
		 * Main Codalix_Market_Admin Instance
		 *
		 * Ensures only one instance of this class exists in memory at any one time.
		 *
		 * @return object The one true Codalix_Market_Admin.
		 * @codeCoverageIgnore
		 * @uses Codalix_Market_Admin::init_actions() Setup hooks and actions.
		 *
		 * @since 1.0.0
		 * @static
		 * @see  Codalix_Market_Admin()
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
				self::$_instance->init_actions();
			}

			return self::$_instance;
		}

		/**
		 * A dummy constructor to prevent this class from being loaded more than once.
		 *
		 * @see Codalix_Market_Admin::instance()
		 *
		 * @since 1.0.0
		 * @access private
		 * @codeCoverageIgnore
		 */
		private function __construct() {
			/* We do nothing here! */
		}

		/**
		 * You cannot clone this class.
		 *
		 * @since 1.0.0
		 * @codeCoverageIgnore
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'codalix-market' ), '1.0.0' );
		}

		/**
		 * You cannot unserialize instances of this class.
		 *
		 * @since 1.0.0
		 * @codeCoverageIgnore
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'codalix-market' ), '1.0.0' );
		}

		/**
		 * Setup the hooks, actions and filters.
		 *
		 * @uses add_action() To add actions.
		 * @uses add_filter() To add filters.
		 *
		 * @since 1.0.0
		 */
		public function init_actions() {
			// @codeCoverageIgnoreStart
			if ( false === codalix_market()->get_data( 'admin' ) && false === codalix_market()->get_option( 'is_plugin_active' ) ) { // Turns the UI off if allowed.
				return;
			}
			// @codeCoverageIgnoreEnd
			// Deferred Download.
			add_action( 'upgrader_package_options', array( $this, 'maybe_deferred_download' ), 9 );

			// Add pre download filter to help with 3rd party plugin integration.
			add_filter( 'upgrader_pre_download', array( $this, 'upgrader_pre_download' ), 2, 4 );

			// Add item AJAX handler.
			add_action( 'wp_ajax_' . self::AJAX_ACTION . '_add_item', array( $this, 'ajax_add_item' ) );

			// Remove item AJAX handler.
			add_action( 'wp_ajax_' . self::AJAX_ACTION . '_remove_item', array( $this, 'ajax_remove_item' ) );

			// Health check AJAX handler
			add_action( 'wp_ajax_' . self::AJAX_ACTION . '_healthcheck', array( $this, 'ajax_healthcheck' ) );

			// Maybe delete the site transients.
			add_action( 'init', array( $this, 'maybe_delete_transients' ), 11 );

			// Add the menu.
			add_action( 'admin_menu', array( $this, 'add_menu_page' ) );

			// Register the settings.
			add_action( 'admin_init', array( $this, 'register_settings' ) );

			// We may need to redirect after an item is enabled.
			add_action( 'current_screen', array( $this, 'maybe_redirect' ) );

			// Add authorization notices.
			add_action( 'current_screen', array( $this, 'add_notices' ) );

			// Set the API values.
			add_action( 'current_screen', array( $this, 'set_items' ) );

			// Hook to verify the API token before saving it.
			add_filter(
				'pre_update_option_' . codalix_market()->get_option_name(),
				array(
					$this,
					'check_api_token_before_saving',
				),
				9,
				3
			);
			add_filter(
				'pre_update_site_option_' . codalix_market()->get_option_name(),
				array(
					$this,
					'check_api_token_before_saving',
				),
				9,
				3
			);

			// When network enabled, add the network options menu.
			add_action( 'network_admin_menu', array( $this, 'add_menu_page' ) );

			// Ability to make use of the Settings API when in multisite mode.
			add_action( 'network_admin_edit_codalix_market_network_settings', array( $this, 'save_network_settings' ) );
		}

		/**
		 * This runs before we save the Codalix Market options array.
		 * If the token has changed then we set a transient so we can do the update check.
		 *
		 * @param array $value The option to save.
		 * @param array $old_value The old option value.
		 * @param array $option Serialized option value.
		 *
		 * @return array $value The updated option value.
		 * @since 2.0.1
		 */
		public function check_api_token_before_saving( $value, $old_value, $option ) {
			if ( ! empty( $value['token'] ) && ( empty( $old_value['token'] ) || $old_value['token'] != $value['token'] || isset( $_POST['codalix_market'] ) ) ) {
				set_site_transient( codalix_market()->get_option_name() . '_check_token', $value['token'], HOUR_IN_SECONDS );
			}

			return $value;
		}


		/**
		 * Defers building the API download url until the last responsible moment to limit file requests.
		 *
		 * Filter the package options before running an update.
		 *
		 * @param array $options {
		 *     Options used by the upgrader.
		 *
		 * @type string $package Package for update.
		 * @type string $destination Update location.
		 * @type bool   $clear_destination Clear the destination resource.
		 * @type bool   $clear_working Clear the working resource.
		 * @type bool   $abort_if_destination_exists Abort if the Destination directory exists.
		 * @type bool   $is_multi Whether the upgrader is running multiple times.
		 * @type array  $hook_extra Extra hook arguments.
		 * }
		 * @since 1.0.0
		 */
		public function maybe_deferred_download( $options ) {
			$package = $options['package'];
			if ( false !== strrpos( $package, 'deferred_download' ) && false !== strrpos( $package, 'item_id' ) ) {
				parse_str( parse_url( $package, PHP_URL_QUERY ), $vars );
				if ( $vars['item_id'] ) {
					$args               = $this->set_bearer_args( $vars['item_id'] );
					$options['package'] = codalix_market()->api()->download( $vars['item_id'], $args );
				}
			}

			return $options;
		}

		/**
		 * We want to stop certain popular 3rd party scripts from blocking the update process by
		 * adjusting the plugin name slightly so the 3rd party plugin checks stop.
		 *
		 * Currently works for: Visual Composer.
		 *
		 * @param string $reply Package URL.
		 * @param string $package Package URL.
		 * @param object $updater Updater Object.
		 *
		 * @return string $reply    New Package URL.
		 * @since 2.0.0
		 */
		public function upgrader_pre_download( $reply, $package, $updater ) {
			if ( strpos( $package, 'marketplace.codalixmarket.cloud/short-dl' ) !== false ) {
				if ( isset( $updater->skin->plugin_info ) && ! empty( $updater->skin->plugin_info['Name'] ) ) {
					$updater->skin->plugin_info['Name'] = $updater->skin->plugin_info['Name'] . '.';
				} else {
					$updater->skin->plugin_info = array(
						'Name' => 'Name',
					);
				}
			}

			return $reply;
		}

		/**
		 * Returns the bearer arguments for a request with a single use API Token.
		 *
		 * @param int $id The item ID.
		 *
		 * @return array
		 * @since 1.0.0
		 */
		public function set_bearer_args( $id ) {
			$token = '';
			$args  = array();
			foreach ( codalix_market()->get_option( 'items', array() ) as $item ) {
				if ( absint( $item['id'] ) === absint( $id ) ) {
					$token = $item['token'];
					break;
				}
			}
			if ( ! empty( $token ) ) {
				$args = array(
					'headers' => array(
						'Authorization' => 'Bearer ' . $token,
					),
				);
			}

			return $args;
		}

		/**
		 * Maybe delete the site transients.
		 *
		 * @since 1.0.0
		 * @codeCoverageIgnore
		 */
		public function maybe_delete_transients() {
			if ( isset( $_POST[ codalix_market()->get_option_name() ] ) ) {

				// Nonce check.
				if ( isset( $_POST['_wpnonce'] ) && ! wp_verify_nonce( $_POST['_wpnonce'], codalix_market()->get_slug() . '-options' ) ) {
					wp_die( __( 'You do not have sufficient permissions to delete transients.', 'codalix-market' ) );
				}

				self::delete_transients();
			} elseif ( ! codalix_market()->get_option( 'installed_version', 0 ) || version_compare( codalix_market()->get_version(), codalix_market()->get_option( 'installed_version', 0 ), '<' ) ) {

				// When the plugin updates we want to delete transients.
				codalix_market()->set_option( 'installed_version', codalix_market()->get_version() );
				self::delete_transients();

			}
		}

		/**
		 * Delete the site transients.
		 *
		 * @since 1.0.0
		 * @access private
		 */
		private function delete_transients() {
			delete_site_transient( codalix_market()->get_option_name() . '_themes' );
			delete_site_transient( codalix_market()->get_option_name() . '_plugins' );
		}

		/**
		 * Prints out all settings sections added to a particular settings page in columns.
		 *
		 * @param string $page The slug name of the page whos settings sections you want to output.
		 * @param int    $columns The number of columns in each row.
		 *
		 * @since 1.0.0
		 *
		 * @global array $wp_settings_sections Storage array of all settings sections added to admin pages
		 * @global array $wp_settings_fields Storage array of settings fields and info about their pages/sections
		 */
		public static function do_settings_sections( $page, $columns = 2 ) {
			global $wp_settings_sections, $wp_settings_fields;

			// @codeCoverageIgnoreStart
			if ( ! isset( $wp_settings_sections[ $page ] ) ) {
				return;
			}
			// @codeCoverageIgnoreEnd
			foreach ( (array) $wp_settings_sections[ $page ] as $section ) {
				// @codeCoverageIgnoreStart
				if ( ! isset( $wp_settings_fields ) || ! isset( $wp_settings_fields[ $page ] ) || ! isset( $wp_settings_fields[ $page ][ $section['id'] ] ) ) {
					continue;
				}
				// @codeCoverageIgnoreEnd
				// Set the column class.
				$class = 'codalix-market-block';
				?>
							<div class="<?php echo esc_attr( $class ); ?>">
				  <?php
					if ( ! empty( $section['title'] ) ) {
						echo '<h3>' . esc_html( $section['title'] ) . '</h3>' . "\n";
					}
					if ( ! empty( $section['callback'] ) ) {
						call_user_func( $section['callback'], $section );
					}
					?>
								<table class="form-table">
					<?php do_settings_fields( $page, $section['id'] ); ?>
								</table>
							</div>
				<?php
			}
		}

		/**
		 * Adds the menu.
		 *
		 * @since 1.0.0
		 */
		public function add_menu_page() {

			if ( CODALIX_MARKET_NETWORK_ACTIVATED && ! is_super_admin() ) {
				// we do not want to show a menu item for people who do not have permission.
				return;
			}

			$svg_icon = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="48" height="48" viewBox="0 0 48 48">
  <image xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAQAElEQVR4AbxYaZRdVZX+zr33vZpSlSIDAQnIkCBDdAmY1UZcUFFaISgqdNp2KdpOiLSordKi0nYatYMuFcGWRVwqGAkImYAQEWxDyFRJICFkqkpSVakkVa/q1fTGqjfce87pb59XL1QgIL98db+799ln+r59zrnvvvLw5j+KTQXewoULfeBkgNSz2d/vejMCVEtLS3DZZZc50PcGBwfVZZd1eS0tg6ybiBaf9QHpUyBkbBEkYMhd4gukroqJZfFdwzd7k0Fer60MRpItfnc3gkLhXLVjxw6zfv16LaAfiT0JDAcUWNoq6LqrWp5opWK8vEjmlPKbxusJkIE8Zt0fGJjuzT39EnXL/E80Lvn2X8544I7nZ/3+OxtnOyzaOFvKv1n03HlV3H/Hs+fdc8ezswQ/X/TnWYLFtItvf2KW4Ae3rZh9x20rZgm+8Y0/zv7KVx54WxVf/vJZZ3/hC7+YsXDhz+verII3ELAQjY0ftl+8duFFH/iHa76lRxuWZrujZ4c7ClsGDo9tTXYVtvW3jW1LdhS2JtvHWhNt+daj+zNbjx0cbe1vz7X2tKdbj+we2Xp491Dr0d0DrV3tw62H2oe2dhwYbj3SNri1s21ga8/Boa39hzPbervS23o6R1qPdQ2tH+gLVwWB99NPff7ua2+66abY3xLyegLMkpuu8ha+69LPqL7GFcdeKn5/uCNckD4avW2kuzwt1V0+JdVdbE4fLjYPHy5MGekqThvuGiXGpg52jU5Ndman9ncQtL0dmWmJjtS0RGd6Wm/H8NQeQdfwlN7O4Sk9HUOnHOscburpGmo62jnYnOgePrPn8Mh7DuxNfDnRNbo0V7ho6fWfXDTzjUScVMCSm5bEcnbqLZlD+GXfweJ5UcEGNrQ8lQqB8hDQiykFf9z3WPZV4Mo+fU/JXcFTAstHkxqHB6UUAIEFaJVVcAA/9HWkUS4a1XdseMqBPf0fL2drllx//euL8NjtVdciL2Obbiz2B4tTiXKd4jy+AmReHwoC6eSBfwz6x2PKeVKWep91igIV20mN8yXmyoDEpJ14lnNAPspAXMtaEKO5okocy149FgY/mTdv4UnPRWUMvPL57qdPnRON1H1nOFGqM5ZxRfBSHFDEKCFAIiCks1KsEYCWTBQApRQU23nMqBIRAjeWxAFhOe7RZYVyIbj5OAYIRtlQIZcreOlh88+Tps7+JAOvuYTD8aA8w5vstAVD/WNvtdaA45KG3AXSTHFCWiEooXErrjRWHj3GQJA7wKJADBir0LR0XYRjWQCKW0jucNWWZevaKkB5EH8wOeJ7dsrN72z512a86jNRgDqvpqVpNG3fpUMbs+xvUf2D+1gugcDNxHooESRgNTvI5ICr4J2W9dWyhesFSIxgcxg2gcc5KNySLJwFXBtPyAPiS11qpHhmvZl0KYCJnE8oqLp4w+RyGF2guZbWLaPlslamtiKGMcURXIS+izHOEISQs7yJb8GWJKrcFJyT5MCYZcwCjrzzhbiLKRieMLj2iuNRgPist7T5fLHBD2rPY1cOxvv4VS0ovtuomKr3rVF12hgYOVAUoq2BJlmBgaUgd6cHxo2DRDSM+4vVe2icUoPm0+ow7fRJmDKjAU1TahHEhZB1/Sxnk/kVlJhKjAIthYBkrWRfalgW8uJGxvhGe80zZ86LSbmKqgBX1iZS5ArNIUWEpqetQWg1IgHLIRFVYxSq6Uek3nx6LeZedxY+8vW347P/Mw+33tuCb933j/jmPe/HLT+8Ap/+2rvRcs0FmDy1HkYBljNbsZzZkChEjFgKqfgU7LIvbRUZQUVW+WE4yp44/jmhUGLYWKsMSRl2EWKahHWVPG3IOkFkNCgXJmZx6Ufegs/85N245uY5uOT9Z+GM2VPQPL0B9ZNrMPX0JsyacxpaPnQRPveN9+L2uxbg4kvfwtFJTAQIyMJSgKUql30Sh6wEBVkCAh51wxhe9WHXVyKGK0BiVKqZ9QgRyUckXUHEcojIRK4uZF2sEbj6lgvwwZvfjskz6irbxAIKgNYGUahhaCEEGIzXxTD7otPwo3v+CQtueAdiLBvWMWeoEAVXRx2H2z78UhRraUEBwpHDH7+qAjhtJRbKtiA5TRtqZpmZDsE/S+LiiyVs3GD+52bjkqvfisBXUOyuI4PuAwN4dvkuPPyrTXjwFxvwx19vwbq1ezCUzAIyC6GUwuduvgItV50Pxb4MkbSHyPNhOJJ1kC2k2IUjy4ooT2lrqnw5W+WqBtx7vYSYM2ZZ83ASJFyWjFNISF8ESbmkQ7z34+dg7gfPduSlX7kQYvVvt+OX3/0rnl62H02T65ntU1FXV4tnVrfhe19dgf97ejeMAekB+VwRh7sHYSxJkrjlwYWizyxLC8uzYBVFsGzAOHXQxas/VQGVOA+B1lpFJFvm1gmV5raRzBPMumwbwfRz6jH3mnPh+ezOgUvFEA/duwnPPHwQ+RGgtr4eV10/B/OvvRgf+dQlmHPpTAwNGPzq7k1Y8eg2JPrTWPRfj2Pv/kFo5cEIyE4ybzikphgjZbGBD+v70BTpYlZzxgpdubO5GNjp06fbEkqIhCgFhM6SOFMWQkMyX2YsUhoXvuc0NJ5Sw+W1MMZi7bKd2PKnI1AqBhk+4iPYjTp+07QRpy1HcSx/bA++++3V2NeWJrE4HDFm2zD7xlcwQpTE7TjAfqBAJXE5yEZmcFGOClQFYPlycA8GlgKUsaTMrRMRZRM68iHXoqwjqFqLsy6cAi+odO05PIwtzxyGVQFbGJ4W7awbffxmlIWIsCSayRoc6eFS+3HXx5KcJTnLLBsvgPU4LmEpRtpbqSOUp6xSyo4PedywddW/2HqhttoaEVF50pgyV6SMkDY0tLYMv8Zi+swmYHyoQ/v6kU6VSNwi5CM2IjQMB600UPS4SDB0ZBW0kFPcFrRQnF58AcuKAMnC9wERw6RYJb7H/oRnK4NyzOrFEaruIm4gErGaRJhF2S7iM3fV7IfcTvLcb2iKu06W4w0N5DFWZovxtmW2j2Cq+pyVFRDyhivvoBRbkRCt5TmyHmkQVkgThqStCHExD1YRbMf8s6Gb+vjtNQFNIprE3FOHfshtFJqKqLJsLQrzOVh1hEhbPrEsV4BtSFwLOBNIrtrGgoRJQnMLGWd97nUPhpk2Hn1nAxiSt0KaZetE8K3BD1ARqSjE+tYaVR1X7AkCQs+3IZ/lsvcdEQqISN7BGogtlcsYzRfZl7RIsqGphhNbCjCQwxtSQATLernGLdsZFg08HloSF5IUo2k1BTkRIoRlQxGGW0esFSFMlqIIqEBB8RDYNxAA8tLuDBgYrUnYMLv0KcRQiKzOWKGEZF+GdBQBnHv+dMQbY4iEuDWIuHqGcJWotHHklUJ9Yw0unzcTNbUBhfgOjqiQ9rnXHQLYoAIRZqWOgIhgAirjvnI/YQVKPAWSZU3CVUT0IyFGAYbbKZcroaO9nz+aLCTRF8w5HeddOJVCdQUUoqXCgRNJM5LXzPT8K87E9/g+9N//8V5Mn14PeD63hw/DLEu2DQWIVbTg81/5lS0Ekpe4iymPI3Lc8WuCgEUupB0B7TLqfCEvInjsQpIq8Uf3ttYOZDMFSIJj8QC3fnM+ZsycBFlcrUDLG4CIqzgwlENyaBSzZzfjls/P5b9q4rhi3lm4986rcMrUOidAsgyX5RgqpPmI9WKsC1xZBAl8LzDqjQTw6cwsGoeIhCX7hgI0EcFURHF7vPxSD7ZtPUSKlWv6jEZ8/wfXYN4VZ8Pne3+Wq7Ri5W7c9+vNuPPH6xDjd8adt1+JSQ3y9BJxCmvWdWA4GwGerEDAVQggQgyzLVtH0YKwgoD9vBhZqBOyL7NPWAEpltwjVJOsZtY1KUf0I3bVfIRqbiPNeLFkcM/Pn8HBQ33SibA459xp+NZt8/Gzn34YN9wwB+lsEc3NDbj15svx7/92OWaeMZntAAXgzxs6sexP3UyRj4hPG3cOhKhfEeOIBwEQiwFCnlvJCeMZZne5ZBixJ54KY/kccURD0EeFcMiJNA+nhqyEfBdEXIXUSAm33/Yo9u3v5VYBrFKY1FiLi99+Om781Fx87dYrceMnLsOFbzsV9ZJ55k7z1fr57Udxz9Jd+M6X3olND30IW5YuQOuDV+MLHzsflkStz5UISJzf1PBiUCzD9wHZYupEvuDHI45fhUKgImv42mpJ1lKEWEOf5LkSsjKsZ9k4wom+Udz5wzVY89QOFMZkA8JlWG4KZIzKR9EMpUbx+1V78CDfTL/48Xfgo++fhcb6GjQ11KKRCGLMOMl6FKEcKmURJCsCn+8S1spQmPg5QYBUGG4RR5R5jxBBK+sIaxGgDORbVXxDgvJ47Owawc/ueQ5f+uoyPLpyOwaHsi5NiiqUArqODuH+h17AF7/3LDbv6sNXP/1OXPe+WazlqsmEDhTrsbHvw3LrOFAM6FfIB1Cs46OPjaodnHVzVTxAeR7za2GNlZtxK1AVZKxxQowjbinNsmxhmZQivz/2taew+O71uOpjv8bl1/4v3nfDEsxdcB+uu2k17ntsH5oa45j/7jOx+9AQ/vDUfixd00Z7AA+sPYAH1x7Crs40yVOAxy3ErWMmkIcKAHAbQVJGd8J1wgoUzBi3j7aWqyBNja2QNCStiWq56ktc2rEHa8EMxLjSNcgXFLgQMF4dvFgtK2J46UAai3+3B3f9fj9+vOwAFi87hMWPdOKuRw7jrseOYFN7nu1JnplWvseHk0/OpEcf47FIh8bz0lwuNx3kwxZiHGyplGNWyyWjUMk+t4+Qtsy+oELYMA+WkDZg+4ovo4Ibw3gWQczDv1x3IR6596P40dfn4RT+uJe9rLgtPB5Qj08WFathYuNOoIrXQMm+93xaHxDSnnK+8gJwa8CPKWNL+cJQPK4x4TNRAMIwVbBKHROKPMokSXJKShaa5DQ7ClEniklw54GEDUdxccbEzji1ATff+C6cf04zFlx5Dq698mz25KUULIkJhBTTDOt7sIoDeIQvW4htKNR6sUqcvwsU4/F4VIpGEv1IxGXROVjlYq+KI/ehqC/v+4V2z/f5jsmByIa7iOQr2Rbi0tvFuCpV3zifYlnhYoodBTKogPUA65XceQNJMyGGgoyQJ+w4wF91FlwFJeCWYlvwizDI96bGUh0dQLeRIas4QUA636Nzo5276+rjefniMqQurd0PEvqWRAy/J4xbG7htJgNJva2SZ6F/IIcly7biWCKNtc8dwNMbDoOnnZSZFN4tNVha6et0sq8rOxGspDBLZlZWhULqY2WMdW3eFBWTPexjieMXmx33MZ3fdJnUgRfL0dHNdfV1pKJIUjN3snkMrfQV35IPfYqxFKWkhtaSCJmiXDb4w+Pt+MBn/4jb796CZKaEcb6Qjzpe4Bjsy5+6jNCX/gJpVImgJtBQRzYkBo9seqJctnzeSQfXwN0mCrCDgw2RUmMjw8Mv/daqxIvxGt9AssGmMq4QtCBdHDTocgAAA7RJREFUKzQpQuoUKFLEAdadF/GlDSuYQeVxKzDllv2kRshSPUc07EADqQFrLSTAHDorfp1fRpDc2pvp/Ov91oYHs3UhM8HlZ4vqdYIA7i/unMacLo/uS43svM+ge0PDpEAHPg8UJ5IpuCwcwRKcghwZpsPhnMJxtxpkBxEtUdkqAvGt1HPFVGUUhlxDDqIBvm/xTRqTgwy8Q48n0nuW/6GY69mu4kgi2ci3P+nMpuPXRAES0pmMV/D9SUkbFTaMDO68K5vZeH+8drBrUmOQqq2NlYLAUpDiqzvhWb5jsRyDDmJW823AIfBZDoiYimKBJUwUxHQUD8Io7kVR3Oc/WPyyjntlHVNFHVclHcOYrvcLYRMGxhr6/5rMP/+z54f3PvrTcj7RiijqbABGgY6/KYDr2h3V1/N3I2rSfKh1jo0mnxhIrv/P9PC6n5QKLzygTPsj0G0rvHDvalXeswqFl1eb0R1P6vyLa2x2+5M20/qkTW960o5sWm0H16+2A+tW2b6/rDK9f1qlj6590nStWms6VjxlOx57yhx46Fm798Hn9N4H1pk9v3u60PqLlel1P354YPtvfjk6tPd3UKodvn/Q8xqGkslkmRkmP94nXK9eAanSicT55cZGU/T9xkET6P0qVLtMeWhjIdu2Kju8a1lueMfS7NCLyzIjLzySHdnxcHaYGHrxkdzQ9kdTyW3Ls/1bl2cTm1emiWzvphXEyuyxTauyRzeuyvRueiLTs/Hx9JENa3JHNz6Z6d28MnNs48psz+aV+eSulcWxnjWIytt8pXb6KO1DWQ2mJ0Wy91+TfSF7MgHckOt1T09POZXyiqfU1KSCoJgoB7bT9+vaPM9vV8pvU7XeXhWovTWB2V8TxPbGfX+v56m2uO/t8x38fTHP2+fVem2+7+/zPG+/76vdPtTOQHk7A8/brpTaxjZbYp6/mdjOupdiXrBTa/Uy0HAsHo8P52bU5UEuJEtevL/qOpkAaSKNeaI6yolEopROpwujg4OZkZHekXS6fyCT8fuzg7Y/Z0y/1ro/ikaTUTTWH4ZjfWHo9XEDJsMQjPn90VggMfH7tI71GhM/pnWht4LiUa2LPdaWBL3xuE2OjESpfL42l0p1jXHbFNHRIVuHXITWa/F6Aqotx4VABikyOI4E7dAYRkbGUqnUaCZzxmg2OzOfz5+WzecnZfmDPZPP12VzufpcLjeZaKbfnM1me3LZbFOeDi1DuTOdZYLyMs7g4CB/aCeJbplPtowQFw6c+uTX/wMAAP//rvYnqgAAAAZJREFUAwD3oVqeIop5ugAAAABJRU5ErkJggg==" x="0" y="0" width="48" height="48"/>
</svg>';

			$page = add_menu_page(
				__( 'Codalix Market', 'codalix-market' ),
				__( 'Codalix Market', 'codalix-market' ),
				'manage_options',
				codalix_market()->get_slug(),
				array(
					$this,
					'render_admin_callback',
				),
				'data:image/svg+xml;base64,' . base64_encode($svg_icon)
			);

			// Enqueue admin CSS.
			add_action( 'admin_print_styles-' . $page, array( $this, 'admin_enqueue_style' ) );

			// Enqueue admin JavaScript.
			add_action( 'admin_print_scripts-' . $page, array( $this, 'admin_enqueue_script' ) );

			// Add Underscore.js templates.
			add_action( 'admin_footer-' . $page, array( $this, 'render_templates' ) );
		}

		/**
		 * Enqueue admin css.
		 *
		 * @since  1.0.0
		 */
		public function admin_enqueue_style() {
			$file_url = codalix_market()->get_plugin_url() . 'css/codalix-market' . ( is_rtl() ? '-rtl' : '' ) . '.css';
			wp_enqueue_style( codalix_market()->get_slug(), $file_url, array( 'wp-jquery-ui-dialog' ), codalix_market()->get_version() );
		}

		/**
		 * Enqueue admin script.
		 *
		 * @since  1.0.0
		 */
		public function admin_enqueue_script() {
			$min        = ( WP_DEBUG ? '' : '.min' );
			$slug       = codalix_market()->get_slug();
			$version    = codalix_market()->get_version();
			$plugin_url = codalix_market()->get_plugin_url();

			wp_enqueue_script(
				$slug,
				$plugin_url . 'js/codalix-market' . $min . '.js',
				array(
					'jquery',
					'jquery-ui-dialog',
					'wp-util',
				),
				$version,
				true
			);
			wp_enqueue_script(
				$slug . '-updates',
				$plugin_url . 'js/updates' . $min . '.js',
				array(
					'jquery',
					'updates',
					'wp-a11y',
					'wp-util',
				),
				$version,
				true
			);

			// Script data array.
			$exports = array(
				'nonce'  => wp_create_nonce( self::AJAX_ACTION ),
				'action' => self::AJAX_ACTION,
				'i18n'   => array(
					'save'   => __( 'Save', 'codalix-market' ),
					'remove' => __( 'Remove', 'codalix-market' ),
					'cancel' => __( 'Cancel', 'codalix-market' ),
					'error'  => __( 'An unknown error occurred. Try again.', 'codalix-market' ),
				),
			);

			// Export data to JS.
			wp_scripts()->add_data(
				$slug,
				'data',
				sprintf( 'var _codalixMarket = %s;', wp_json_encode( $exports ) )
			);
		}

		/**
		 * Underscore (JS) templates for dialog windows.
		 *
		 * @codeCoverageIgnore
		 */
		public function render_templates() {
			?>
					<script type="text/html" id="tmpl-codalix-market-auth-check-button">
						<a
							href="<?php echo esc_url( add_query_arg( array( 'authorization' => 'check' ), codalix_market()->get_page_url() ) ); ?>"
							class="button button-secondary auth-check-button"
							style="margin:0 5px"><?php esc_html_e( 'Test API Connection', 'codalix-market' ); ?></a>
					</script>

					<script type="text/html" id="tmpl-codalix-market-item">
						<li data-id="{{ data.id }}">
							<span class="item-name"><?php esc_html_e( 'ID', 'codalix-market' ); ?>
								: {{ data.id }} - {{ data.name }}</span>
							<button class="item-delete dashicons dashicons-dismiss">
								<span class="screen-reader-text"><?php esc_html_e( 'Delete', 'codalix-market' ); ?></span>
							</button>
							<input type="hidden"
								   name="<?php echo esc_attr( codalix_market()->get_option_name() ); ?>[items][{{ data.key }}][name]"
								   value="{{ data.name }}"/>
							<input type="hidden"
								   name="<?php echo esc_attr( codalix_market()->get_option_name() ); ?>[items][{{ data.key }}][token]"
								   value="{{ data.token }}"/>
							<input type="hidden"
								   name="<?php echo esc_attr( codalix_market()->get_option_name() ); ?>[items][{{ data.key }}][id]"
								   value="{{ data.id }}"/>
							<input type="hidden"
								   name="<?php echo esc_attr( codalix_market()->get_option_name() ); ?>[items][{{ data.key }}][type]"
								   value="{{ data.type }}"/>
							<input type="hidden"
								   name="<?php echo esc_attr( codalix_market()->get_option_name() ); ?>[items][{{ data.key }}][authorized]"
								   value="{{ data.authorized }}"/>
						</li>
					</script>

					<script type="text/html" id="tmpl-codalix-market-dialog-remove">
						<div id="codalix-market-dialog-remove" title="<?php esc_html_e( 'Remove Item', 'codalix-market' ); ?>">
							<p><?php esc_html_e( 'You are about to remove the connection between the Codalix Market API and this item. You cannot undo this action.', 'codalix-market' ); ?></p>
						</div>
					</script>

					<script type="text/html" id="tmpl-codalix-market-dialog-form">
						<div id="codalix-market-dialog-form" title="<?php esc_html_e( 'Add Item', 'codalix-market' ); ?>">
							<form>
								<fieldset>
									<label for="token"><?php esc_html_e( 'Token', 'codalix-market' ); ?></label>
									<input type="text" name="token" class="widefat" value=""/>
									<p
										class="description"><?php esc_html_e( 'Enter the Codalix API Personal Token.', 'codalix-market' ); ?></p>
									<label for="id"><?php esc_html_e( 'Item ID', 'codalix-market' ); ?></label>
									<input type="text" name="id" class="widefat" value=""/>
									<p class="description"><?php esc_html_e( 'Enter the Codalix Item ID.', 'codalix-market' ); ?></p>
									<input type="submit" tabindex="-1" style="position:absolute; top:-5000px"/>
								</fieldset>
							</form>
						</div>
					</script>

					<script type="text/html" id="tmpl-codalix-market-dialog-error">
						<div class="notice notice-error">
							<p>{{ data.message }}</p>
						</div>
					</script>

					<script type="text/html" id="tmpl-codalix-market-card">
						<div class="codalix-market-block" data-id="{{ data.id }}">
							<div class="codalix-card {{ data.type }}">
								<div class="codalix-card-top">
									<a href="{{ data.url }}" class="column-icon">
										<img src="{{ data.thumbnail_url }}"/>
									</a>
									<div class="column-name">
										<h4>
											<a href="{{ data.url }}">{{ data.name }}</a>
											<span class="version"
												  aria-label="<?php esc_attr_e( 'Version %s', 'codalix-market' ); ?>"><?php esc_html_e( 'Version', 'codalix-market' ); ?>
												{{ data.version }}</span>
										</h4>
									</div>
									<div class="column-description">
										<div class="description">
											<p>{{ data.description }}</p>
										</div>
										<p class="author">
											<cite><?php esc_html_e( 'By', 'codalix-market' ); ?> {{ data.author }}</cite>
										</p>
									</div>
								</div>
								<div class="codalix-card-bottom">
									<div class="column-actions">
										<a href="{{{ data.install }}}" class="button button-primary">
											<span aria-hidden="true"><?php esc_html_e( 'Install', 'codalix-market' ); ?></span>
											<span class="screen-reader-text"><?php esc_html_e( 'Install', 'codalix-market' ); ?> {{ data.name }}</span>
										</a>
									</div>
								</div>
							</div>
						</div>
					</script>
			<?php
		}

		/**
		 * Registers the settings.
		 *
		 * @since 1.0.0
		 */
		public function register_settings() {
			// Setting.
			register_setting( codalix_market()->get_slug(), codalix_market()->get_option_name() );

			// OAuth section.
			add_settings_section(
				codalix_market()->get_option_name() . '_oauth_section',
				__( 'Getting Started (Simple)', 'codalix-market' ),
				array( $this, 'render_oauth_section_callback' ),
				codalix_market()->get_slug()
			);

			// Token setting.
			add_settings_field(
				'token',
				__( 'Token', 'codalix-market' ),
				array( $this, 'render_token_setting_callback' ),
				codalix_market()->get_slug(),
				codalix_market()->get_option_name() . '_oauth_section'
			);

			// Items section.
			add_settings_section(
				codalix_market()->get_option_name() . '_items_section',
				__( 'Single Item Tokens (Advanced)', 'codalix-market' ),
				array( $this, 'render_items_section_callback' ),
				codalix_market()->get_slug()
			);

			// Items setting.
			add_settings_field(
				'items',
				__( 'Codalix Market Items', 'codalix-market' ),
				array( $this, 'render_items_setting_callback' ),
				codalix_market()->get_slug(),
				codalix_market()->get_option_name() . '_items_section'
			);
		}

		/**
		 * Redirect after the enable action runs.
		 *
		 * @since 1.0.0
		 * @codeCoverageIgnore
		 */
		public function maybe_redirect() {
			if ( $this->are_we_on_settings_page() ) {

				if ( ! empty( $_GET['action'] ) && 'install-theme' === $_GET['action'] && ! empty( $_GET['enabled'] ) ) {
					wp_safe_redirect( esc_url( codalix_market()->get_page_url() ) );
					exit;
				}
			}
		}

		/**
		 * Add authorization notices.
		 *
		 * @since 1.0.0
		 */
		public function add_notices() {

			if ( $this->are_we_on_settings_page() ) {

				// @codeCoverageIgnoreStart
				if ( get_site_transient( codalix_market()->get_option_name() . '_check_token' ) || ( isset( $_GET['authorization'] ) && 'check' === $_GET['authorization'] ) ) {
					delete_site_transient( codalix_market()->get_option_name() . '_check_token' );
					self::authorization_redirect();
				}
				// @codeCoverageIgnoreEnd
				// Get the option array.
				$option = codalix_market()->get_options();

				// Display success/error notices.
				if ( ! empty( $option['notices'] ) ) {
					self::delete_transients();

					// Show succes notice.
					if ( isset( $option['notices']['success'] ) ) {
						add_action(
							( CODALIX_MARKET_NETWORK_ACTIVATED ? 'network_' : '' ) . 'admin_notices',
							array(
								$this,
								'render_success_notice',
							)
						);
					}

					// Show succes no-items notice.
					if ( isset( $option['notices']['success-no-items'] ) ) {
						add_action(
							( CODALIX_MARKET_NETWORK_ACTIVATED ? 'network_' : '' ) . 'admin_notices',
							array(
								$this,
								'render_success_no_items_notice',
							)
						);
					}

					// Show single-use succes notice.
					if ( isset( $option['notices']['success-single-use'] ) ) {
						add_action(
							( CODALIX_MARKET_NETWORK_ACTIVATED ? 'network_' : '' ) . 'admin_notices',
							array(
								$this,
								'render_success_single_use_notice',
							)
						);
					}

					// Show error notice.
					if ( isset( $option['notices']['error'] ) ) {
						add_action(
							( CODALIX_MARKET_NETWORK_ACTIVATED ? 'network_' : '' ) . 'admin_notices',
							array(
								$this,
								'render_error_notice',
							)
						);
					}

					// Show invalid permissions error notice.
					if ( isset( $option['notices']['error-permissions'] ) ) {
						add_action(
							( CODALIX_MARKET_NETWORK_ACTIVATED ? 'network_' : '' ) . 'admin_notices',
							array(
								$this,
								'render_error_permissions',
							)
						);
					}

					// Show single-use error notice.
					if ( isset( $option['notices']['error-single-use'] ) ) {
						add_action(
							( CODALIX_MARKET_NETWORK_ACTIVATED ? 'network_' : '' ) . 'admin_notices',
							array(
								$this,
								'render_error_single_use_notice',
							)
						);
					}

					// Show missing zip notice.
					if ( isset( $option['notices']['missing-package-zip'] ) ) {
						add_action(
							( CODALIX_MARKET_NETWORK_ACTIVATED ? 'network_' : '' ) . 'admin_notices',
							array(
								$this,
								'render_error_missing_zip',
							)
						);
					}

					// Show missing http connection error.
					if ( isset( $option['notices']['http_error'] ) ) {
						add_action(
							( CODALIX_MARKET_NETWORK_ACTIVATED ? 'network_' : '' ) . 'admin_notices',
							array(
								$this,
								'render_error_http',
							)
						);
					}

					// Update the saved data so the notice disappears on the next page load.
					unset( $option['notices'] );

					codalix_market()->set_options( $option );
				}
			}
		}

		/**
		 * Set the API values.
		 *
		 * @since 1.0.0
		 */
		public function set_items() {
			if ( $this->are_we_on_settings_page() ) {
				codalix_market()->items()->set_themes();
				codalix_market()->items()->set_plugins();
			}
		}

		/**
		 * Check if we're on the settings page.
		 *
		 * @since 2.0.0
		 * @access private
		 */
		private function are_we_on_settings_page() {
			return 'toplevel_page_' . codalix_market()->get_slug() === get_current_screen()->id || 'toplevel_page_' . codalix_market()->get_slug() . '-network' === get_current_screen()->id;
		}

		/**
		 * Check for authorization and redirect.
		 *
		 * @since 1.0.0
		 * @access private
		 * @codeCoverageIgnore
		 */
		private function authorization_redirect() {
			self::authorization();
			wp_safe_redirect( esc_url( codalix_market()->get_page_url() . '#settings' ) );
			exit;
		}

		/**
		 * Set the Codalix API authorization value.
		 *
		 * @since 1.0.0
		 */
		public function authorization() {
			// Get the option array.
			$option            = codalix_market()->get_options();
			$option['notices'] = array();

			// Check for global token.
			if ( codalix_market()->get_option( 'token' ) || codalix_market()->api()->token ) {

				$notice      = 'success';
				$scope_check = $this->authorize_token_permissions();

				if ( 'http_error' === $scope_check ) {
					$notice = 'http_error';
				} elseif ( 'error' === $this->authorize_total_items() || 'error' === $scope_check ) {
					$notice = 'error';
				} else {
					if ( 'missing-permissions' == $scope_check ) {
						$notice = 'error-permissions';
					} elseif ( 'too-many-permissions' === $scope_check ) {
						$notice = 'error-permissions';
					} else {
						$themes_notice  = $this->authorize_themes();
						$plugins_notice = $this->authorize_plugins();
						if ( 'error' === $themes_notice || 'error' === $plugins_notice ) {
							$notice = 'error';
						} elseif ( 'success-no-themes' === $themes_notice && 'success-no-plugins' === $plugins_notice ) {
							$notice = 'success-no-items';
						}
					}
				}
				$option['notices'][ $notice ] = true;
			}

			// Check for single-use token.
			if ( ! empty( $option['items'] ) ) {
				$failed = false;

				foreach ( $option['items'] as $key => $item ) {
					if ( empty( $item['name'] ) || empty( $item['token'] ) || empty( $item['id'] ) || empty( $item['type'] ) || empty( $item['authorized'] ) ) {
						continue;
					}

					$request_args = array(
						'headers' => array(
							'Authorization' => 'Bearer ' . $item['token'],
						),
					);

					// Uncached API response with single-use token.
					$response = codalix_market()->api()->item( $item['id'], $request_args );

					if ( ! is_wp_error( $response ) && isset( $response['id'] ) ) {
						$option['items'][ $key ]['authorized'] = 'success';
					} else {
						if ( is_wp_error( $response ) ) {
							$this->store_additional_error_debug_information( 'Unable to query single item ID ' . $item['id'], $response->get_error_message(), $response->get_error_data() );
						}
						$failed                                = true;
						$option['items'][ $key ]['authorized'] = 'failed';
					}
				}

				if ( true === $failed ) {
					$option['notices']['error-single-use'] = true;
				} else {
					$option['notices']['success-single-use'] = true;
				}
			}

			// Set the option array.
			if ( ! empty( $option['notices'] ) ) {
				codalix_market()->set_options( $option );
			}
		}

		/**
		 * Check that themes are authorized.
		 *
		 * @return bool
		 * @since 1.0.0
		 */
		public function authorize_total_items() {
			$domain = codalix_market()->get_codalix_api_domain();
			$path = codalix_market()->api()->api_path_for('total-items');
			$url = $domain . $path;
			$response = codalix_market()->api()->request( $url );
			$notice   = 'success';

			if ( is_wp_error( $response ) ) {
				$notice = 'error';
				$this->store_additional_error_debug_information( 'Failed to query total number of items in API response', $response->get_error_message(), $response->get_error_data() );
			} elseif ( ! isset( $response['total-items'] ) ) {
				$notice = 'error';
				$this->store_additional_error_debug_information( 'Incorrect response from API when querying total items' );
			}

			return $notice;
		}


		/**
		 * Get the required API permissions for this plugin to work.
		 *
		 * @single 2.0.1
		 *
		 * @return array
		 */
		public function get_required_permissions() {
			return apply_filters(
				'codalix_market_required_permissions',
				array(
					'default'           => 'View and search Codalix sites',
					'purchase:download' => 'Download your purchased items',
					'purchase:list'     => 'List purchases you\'ve made',
				)
			);
		}

		/**
		 * Return the URL a user needs to click to generate a personal token.
		 *
		 * @single 2.0.1
		 *
		 * @return string The full URL to request a token.
		 */
		public function get_generate_token_url() {
			return 'https://build.codalixmarket.cloud/create-token/?' . implode(
				'&',
				array_map(
					function ( $val ) {
							return $val . '=t';
					},
					array_keys( $this->get_required_permissions() )
				)
			);
		}

		/**
		 * Check that themes are authorized.
		 *
		 * @return bool
		 * @since 1.0.0
		 */
		public function authorize_token_permissions() {
			if ( defined('CODALIX_LOCAL_DEVELOPMENT') ) {
				return 'success';
			}
      $notice = 'success';
			$response = codalix_market()->api()->request( 'https://api.codalixmarket.cloud/whoami' );

			if ( is_wp_error( $response ) && ( $response->get_error_code() === 'http_error' || $response->get_error_code() == 500 ) ) {
				$this->store_additional_error_debug_information( 'An error occured checking token permissions', $response->get_error_message(), $response->get_error_data() );
				$notice = 'http_error';
			} elseif ( is_wp_error( $response ) || ! isset( $response['scopes'] ) || ! is_array( $response['scopes'] ) ) {
				$this->store_additional_error_debug_information( 'No scopes found in API response message', $response->get_error_message(), $response->get_error_data() );
				$notice = 'error';
			} else {

				$minimum_scopes = $this->get_required_permissions();
				$maximum_scopes = array( 'default' => 'Default' ) + $minimum_scopes;

				foreach ( $minimum_scopes as $required_scope => $required_scope_name ) {
					if ( ! in_array( $required_scope, $response['scopes'] ) ) {
						// The scope minimum required scope doesn't exist.
						$this->store_additional_error_debug_information( 'Could not find required API permission scope in output.', $required_scope );
						$notice = 'missing-permissions';
					}
				}
				foreach ( $response['scopes'] as $scope ) {
					if ( ! isset( $maximum_scopes[ $scope ] ) ) {
						// The available scope is outside our maximum bounds.
						$this->store_additional_error_debug_information( 'Found too many permissions on token.', $scope );
						$notice = 'too-many-permissions';
					}
				}
			}

			return $notice;
		}

		/**
		 * Check that themes or plugins are authorized and downloadable.
		 *
		 * @param string $type The filter type, either 'themes' or 'plugins'. Default 'themes'.
		 *
		 * @return bool|null
		 * @since 1.0.0
		 */
		public function authorize_items( $type = 'themes' ) {
			$domain = codalix_market()->get_codalix_api_domain();
			$path = codalix_market()->api()->api_path_for('list-purchases');
			$api_url      = $domain . $path . '?filter_by=wordpress-' . $type;
			$response = codalix_market()->api()->request( $api_url );
			$notice   = 'success';

			if ( is_wp_error( $response ) ) {
				$notice = 'error';
				$this->store_additional_error_debug_information( 'Error listing buyer purchases.', $response->get_error_message(), $response->get_error_data() );
			} elseif ( empty( $response ) ) {
				$notice = 'error';
				$this->store_additional_error_debug_information( 'Empty API result listing buyer purchases' );
			} elseif ( empty( $response['results'] ) ) {
				$notice = 'success-no-' . $type;
			} else {
				shuffle( $response['results'] );
				$item = array_shift( $response['results'] );
				if ( ! isset( $item['item']['id'] ) || ! codalix_market()->api()->download( $item['item']['id'] ) ) {
					$this->store_additional_error_debug_information( 'Failed to find the correct item format in API response' );
					$notice = 'error';
				}
			}

			return $notice;
		}

		/**
		 * Check that themes are authorized.
		 *
		 * @return bool
		 * @since 1.0.0
		 */
		public function authorize_themes() {
			return $this->authorize_items( 'themes' );
		}

		/**
		 * Check that plugins are authorized.
		 *
		 * @return bool
		 * @since 1.0.0
		 */
		public function authorize_plugins() {
			return $this->authorize_items( 'plugins' );
		}

		/**
		 * Install plugin.
		 *
		 * @param string $plugin The plugin item ID.
		 *
		 * @since 1.0.0
		 * @codeCoverageIgnore
		 */
		public function install_plugin( $plugin ) {
			if ( ! current_user_can( 'install_plugins' ) ) {
				$msg = '
				<div class="wrap">
					<h1>' . __( 'Installing Plugin...', 'codalix-market' ) . '</h1>
					<p>' . __( 'You do not have sufficient permissions to install plugins on this site.', 'codalix-market' ) . '</p>
					<a href="' . esc_url( 'admin.php?page=' . codalix_market()->get_slug() . '&tab=plugins' ) . '">' . __( 'Return to Plugin Installer', 'codalix-market' ) . '</a>
				</div>';
				wp_die( $msg );
			}

			check_admin_referer( 'install-plugin_' . $plugin );

			codalix_market()->items()->set_plugins( true );
			$install = codalix_market()->items()->plugins( 'install' );
			$api     = new stdClass();

			foreach ( $install as $value ) {
				if ( absint( $value['id'] ) === absint( $plugin ) ) {
					$api->name    = $value['name'];
					$api->version = $value['version'];
				}
			}

			$array_api = (array) $api;

			if ( empty( $array_api ) ) {
				$msg = '
				<div class="wrap">
					<h1>' . __( 'Installing Plugin...', 'codalix-market' ) . '</h1>
					<p>' . __( 'An error occurred, please check that the item ID is correct.', 'codalix-market' ) . '</p>
					<a href="' . esc_url( 'admin.php?page=' . codalix_market()->get_slug() . '&tab=plugins' ) . '">' . __( 'Return to Plugin Installer', 'codalix-market' ) . '</a>
				</div>';
				wp_die( $msg );
			}

			$title              = sprintf( __( 'Installing Plugin: %s', 'codalix-market' ), esc_html( $api->name . ' ' . $api->version ) );
			$nonce              = 'install-plugin_' . $plugin;
			$url                = 'admin.php?page=' . codalix_market()->get_slug() . '&action=install-plugin&plugin=' . urlencode( $plugin );
			$type               = 'web'; // Install plugin type, From Web or an Upload.
			$api->download_link = codalix_market()->api()->download( $plugin, $this->set_bearer_args( $plugin ) );

			// Must have the upgrader & skin.
			require codalix_market()->get_plugin_path() . '/inc/admin/class-codalix-market-theme-upgrader.php';
			require codalix_market()->get_plugin_path() . '/inc/admin/class-codalix-market-theme-installer-skin.php';

			$upgrader = new Codalix_Market_Plugin_Upgrader( new Codalix_Market_Plugin_Installer_Skin( compact( 'title', 'url', 'nonce', 'plugin', 'api' ) ) );
			$upgrader->install( $api->download_link );
		}

		/**
		 * Install theme.
		 *
		 * @param string $theme The theme item ID.
		 *
		 * @since 1.0.0
		 * @codeCoverageIgnore
		 */
		public function install_theme( $theme ) {
			if ( ! current_user_can( 'install_themes' ) ) {
				$msg = '
				<div class="wrap">
					<h1>' . __( 'Installing Theme...', 'codalix-market' ) . '</h1>
					<p>' . __( 'You do not have sufficient permissions to install themes on this site.', 'codalix-market' ) . '</p>
					<a href="' . esc_url( 'admin.php?page=' . codalix_market()->get_slug() . '&tab=themes' ) . '">' . __( 'Return to Theme Installer', 'codalix-market' ) . '</a>
				</div>';
				wp_die( $msg );
			}

			check_admin_referer( 'install-theme_' . $theme );

			codalix_market()->items()->set_themes( true );
			$install = codalix_market()->items()->themes( 'install' );
			$api     = new stdClass();

			foreach ( $install as $value ) {
				if ( absint( $value['id'] ) === absint( $theme ) ) {
					$api->name    = $value['name'];
					$api->version = $value['version'];
				}
			}

			$array_api = (array) $api;

			if ( empty( $array_api ) ) {
				$msg = '
				<div class="wrap">
					<h1>' . __( 'Installing Theme...', 'codalix-market' ) . '</h1>
					<p>' . __( 'An error occurred, please check that the item ID is correct.', 'codalix-market' ) . '</p>
					<a href="' . esc_url( 'admin.php?page=' . codalix_market()->get_slug() . '&tab=themes' ) . '">' . __( 'Return to Plugin Installer', 'codalix-market' ) . '</a>
				</div>';
				wp_die( $msg );
			}

			wp_enqueue_script( 'customize-loader' );

			$title              = sprintf( __( 'Installing Theme: %s', 'codalix-market' ), esc_html( $api->name . ' ' . $api->version ) );
			$nonce              = 'install-theme_' . $theme;
			$url                = 'admin.php?page=' . codalix_market()->get_slug() . '&action=install-theme&theme=' . urlencode( $theme );
			$type               = 'web'; // Install theme type, From Web or an Upload.
			$api->download_link = codalix_market()->api()->download( $theme, $this->set_bearer_args( $theme ) );

			// Must have the upgrader & skin.
			require_once codalix_market()->get_plugin_path() . '/inc/admin/class-codalix-market-theme-upgrader.php';
			require_once codalix_market()->get_plugin_path() . '/inc/admin/class-codalix-market-theme-installer-skin.php';

			$upgrader = new Codalix_Market_Theme_Upgrader( new Codalix_Market_Theme_Installer_Skin( compact( 'title', 'url', 'nonce', 'api' ) ) );
			$upgrader->install( $api->download_link );
		}

		/**
		 * AJAX handler for adding items that use a non global token.
		 *
		 * @since 1.0.0
		 * @codeCoverageIgnore
		 */
		public function ajax_add_item() {
			if ( ! check_ajax_referer( self::AJAX_ACTION, 'nonce', false ) ) {
				status_header( 400 );
				wp_send_json_error( 'bad_nonce' );
			} elseif ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
				status_header( 405 );
				wp_send_json_error( 'bad_method' );
			} elseif ( empty( $_POST['token'] ) ) {
				wp_send_json_error( array( 'message' => __( 'The Token is missing.', 'codalix-market' ) ) );
			} elseif ( empty( $_POST['id'] ) ) {
				wp_send_json_error( array( 'message' => __( 'The Item ID is missing.', 'codalix-market' ) ) );
			} elseif ( ! current_user_can( 'install_themes' ) || ! current_user_can( 'install_plugins' ) ) {
				wp_send_json_error( array( 'message' => __( 'User not allowed to install items.', 'codalix-market' ) ) );
			}

			$args = array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $_POST['token'],
				),
			);

			$request = codalix_market()->api()->item( $_POST['id'], $args );
			if ( false === $request ) {
				wp_send_json_error( array( 'message' => __( 'The Token or Item ID is incorrect.', 'codalix-market' ) ) );
			}

			if ( false === codalix_market()->api()->download( $_POST['id'], $args ) ) {
				wp_send_json_error( array( 'message' => __( 'The item cannot be downloaded.', 'codalix-market' ) ) );
			}

			if ( isset( $request['number_of_sales'] ) ) {
				$type = 'plugin';
			} else {
				$type = 'theme';
			}

			if ( isset( $type ) ) {
				$response = array(
					'name'       => $request['name'],
					'token'      => $_POST['token'],
					'id'         => $_POST['id'],
					'type'       => $type,
					'authorized' => 'success',
				);

				$options = get_option( codalix_market()->get_option_name(), array() );

				if ( ! empty( $options['items'] ) ) {
					$options['items'] = array_values( $options['items'] );
					$key              = count( $options['items'] );
				} else {
					$options['items'] = array();
					$key              = 0;
				}

				$options['items'][] = $response;

				codalix_market()->set_options( $options );

				// Rebuild the theme cache.
				if ( 'theme' === $type ) {
					codalix_market()->items()->set_themes( true, false );

					$install_link = add_query_arg(
						array(
							'page'   => codalix_market()->get_slug(),
							'action' => 'install-theme',
							'id'     => $_POST['id'],
						),
						self_admin_url( 'admin.php' )
					);

					$request['install'] = wp_nonce_url( $install_link, 'install-theme_' . $_POST['id'] );
				}

				// Rebuild the plugin cache.
				if ( 'plugin' === $type ) {
					codalix_market()->items()->set_plugins( true, false );

					$install_link = add_query_arg(
						array(
							'page'   => codalix_market()->get_slug(),
							'action' => 'install-plugin',
							'id'     => $_POST['id'],
						),
						self_admin_url( 'admin.php' )
					);

					$request['install'] = wp_nonce_url( $install_link, 'install-plugin_' . $_POST['id'] );
				}

				$response['key']  = $key;
				$response['item'] = $request;
				wp_send_json_success( $response );
			}

			wp_send_json_error( array( 'message' => __( 'An unknown error occurred.', 'codalix-market' ) ) );
		}

		/**
		 * AJAX handler for removing items that use a non global token.
		 *
		 * @since 1.0.0
		 * @codeCoverageIgnore
		 */
		public function ajax_remove_item() {
			if ( ! check_ajax_referer( self::AJAX_ACTION, 'nonce', false ) ) {
				status_header( 400 );
				wp_send_json_error( 'bad_nonce' );
			} elseif ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
				status_header( 405 );
				wp_send_json_error( 'bad_method' );
			} elseif ( empty( $_POST['id'] ) ) {
				wp_send_json_error( array( 'message' => __( 'The Item ID is missing.', 'codalix-market' ) ) );
			} elseif ( ! current_user_can( 'delete_plugins' ) || ! current_user_can( 'delete_themes' ) ) {
				wp_send_json_error( array( 'message' => __( 'User not allowed to update items.', 'codalix-market' ) ) );
			}

			$options = get_option( codalix_market()->get_option_name(), array() );
			$type    = '';

			foreach ( $options['items'] as $key => $item ) {
				if ( $item['id'] === $_POST['id'] ) {
					$type = $item['type'];
					unset( $options['items'][ $key ] );
					break;
				}
			}
			$options['items'] = array_values( $options['items'] );

			codalix_market()->set_options( $options );

			// Rebuild the theme cache.
			if ( 'theme' === $type ) {
				codalix_market()->items()->set_themes( true, false );
			}

			// Rebuild the plugin cache.
			if ( 'plugin' === $type ) {
				codalix_market()->items()->set_plugins( true, false );
			}

			wp_send_json_success();
		}

		/**
		 * AJAX handler for performing a healthcheck of the current website.
		 *
		 * @since 2.0.6
		 * @codeCoverageIgnore
		 */
		public function ajax_healthcheck() {
			if ( ! check_ajax_referer( self::AJAX_ACTION, 'nonce', false ) ) {
				status_header( 400 );
				wp_send_json_error( 'bad_nonce' );
			} elseif ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
				status_header( 405 );
				wp_send_json_error( 'bad_method' );
			} elseif ( ! current_user_can( 'install_themes' ) || ! current_user_can( 'install_plugins' ) ) {
				wp_send_json_error( array( 'message' => __( 'User not allowed to install items.', 'codalix-market' ) ) );
			}

			$limits = $this->get_server_limits();

			wp_send_json_success( array(
				'limits' => $limits
			) );
		}

	  /**
	   * AJAX handler for performing a healthcheck of the current website.
	   *
	   * @since 2.0.6
	   * @codeCoverageIgnore
	   */
	  public function get_server_limits() {
		  $limits = [];

		  // Check memory limit is > 256 M
		  try {
			  $memory_limit         = wp_convert_hr_to_bytes( ini_get( 'memory_limit' ) );
			  $memory_limit_desired = 256;
			  $memory_limit_ok      = $memory_limit < 0 || $memory_limit >= $memory_limit_desired * 1024 * 1024;
			  $memory_limit_in_mb   = $memory_limit < 0 ? 'Unlimited' : floor( $memory_limit / ( 1024 * 1024 ) ) . 'M';

			  $limits['memory_limit'] = [
				  'title'   => 'PHP Memory Limit',
				  'ok'      => $memory_limit_ok,
				  'message' => $memory_limit_ok ? "is ok at {$memory_limit_in_mb}." : "{$memory_limit_in_mb} may be too small. If you are having issues please set your PHP memory limit to at least 256M - or ask your hosting provider to do this if you're unsure."
			  ];
		  } catch ( \Exception $e ) {
			  $limits['memory_limit'] = [
				  'title'   => 'PHP Memory Limit',
				  'ok'      => false,
				  'message' => 'Failed to check memory limit. If you are having issues please ask hosting provider to raise the memory limit for you.'
			  ];
		  }

		  // Check upload size.
		  try {
			  $upload_size_desired = 80;

			  $upload_max_filesize       = wp_max_upload_size();
			  $upload_max_filesize_ok    = $upload_max_filesize < 0 || $upload_max_filesize >= $upload_size_desired * 1024 * 1024;
			  $upload_max_filesize_in_mb = $upload_max_filesize < 0 ? 'Unlimited' : floor( $upload_max_filesize / ( 1024 * 1024 ) ) . 'M';

			  $limits['upload'] = [
				  'ok'      => $upload_max_filesize_ok,
				  'title'   => 'PHP Upload Limits',
				  'message' => $upload_max_filesize_ok ? "is ok at $upload_max_filesize_in_mb." : "$upload_max_filesize_in_mb may be too small. If you are having issues please set your PHP upload limits to at least {$upload_size_desired}M - or ask your hosting provider to do this if you're unsure.",
			  ];
		  } catch ( \Exception $e ) {
			  $limits['upload'] = [
				  'title'   => 'PHP Upload Limits',
				  'ok'      => false,
				  'message' => 'Failed to check upload limit. If you are having issues please ask hosting provider to raise the upload limit for you.'
			  ];
		  }

		  // Check max_input_vars.
		  try {
			  $max_input_vars         = ini_get( 'max_input_vars' );
			  $max_input_vars_desired = 1000;
			  $max_input_vars_ok      = $max_input_vars < 0 || $max_input_vars >= $max_input_vars_desired;

			  $limits['max_input_vars'] = [
				  'ok'      => $max_input_vars_ok,
				  'title'   => 'PHP Max Input Vars',
				  'message' => $max_input_vars_ok ? "is ok at $max_input_vars." : "$max_input_vars may be too small. If you are having issues please set your PHP max input vars to at least $max_input_vars_desired - or ask your hosting provider to do this if you're unsure.",
			  ];
		  } catch ( \Exception $e ) {
			  $limits['max_input_vars'] = [
				  'title'   => 'PHP Max Input Vars',
				  'ok'      => false,
				  'message' => 'Failed to check input vars limit. If you are having issues please ask hosting provider to raise the input vars limit for you.'
			  ];
		  }

		  // Check max_execution_time.
		  try {
			  $max_execution_time         = ini_get( 'max_execution_time' );
			  $max_execution_time_desired = 60;
			  $max_execution_time_ok      = $max_execution_time <= 0 || $max_execution_time >= $max_execution_time_desired;

			  $limits['max_execution_time'] = [
				  'ok'      => $max_execution_time_ok,
				  'title'   => 'PHP Execution Time',
				  'message' => $max_execution_time_ok ? "PHP execution time limit is ok at {$max_execution_time}." : "$max_execution_time is too small. Please set your PHP max execution time to at least $max_execution_time_desired - or ask your hosting provider to do this if you're unsure.",
			  ];
		  } catch ( \Exception $e ) {
			  $limits['max_execution_time'] = [
				  'title'   => 'PHP Execution Time',
				  'ok'      => false,
				  'message' => 'Failed to check PHP execution time limit. Please ask hosting provider to raise this limit for you.'
			  ];
		  }

		  // Check various hostname connectivity.
		  $hosts_to_check = array(
			  array(
				  'hostname' => 'codalix-market.github.io',
				  'url'      => 'https://codalix-market.github.io/wp-codalix-market/dist/update-check.json',
				  'title'    => 'Plugin Update API',
			  ),
			  array(
				  'hostname' => 'api.codalixmarket.cloud',
				  'url'      => 'https://api.codalixmarket.cloud/ping',
				  'title'    => 'Codalix Market API',
			  ),
			  array(
				  'hostname' => 'marketplace.codalixmarket.cloud',
				  'url'      => 'https://marketplace.codalixmarket.cloud/robots.txt',
				  'title'    => 'Download API',
			  ),
		  );

		  foreach ( $hosts_to_check as $host ) {
			  try {
				  $response      = wp_remote_get( $host['url'], [
					  'user-agent' => 'WordPress - Codalix Market ' . codalix_market()->get_version(),
					  'timeout'    => 5,
				  ] );
				  $response_code = wp_remote_retrieve_response_code( $response );
				  if ( $response && ! is_wp_error( $response ) && $response_code === 200 ) {
					  $limits[ $host['hostname'] ] = [
						  'ok'      => true,
						  'title'   => $host['title'],
						  'message' => 'Connected ok.',
					  ];
				  } else {
					  $limits[ $host['hostname'] ] = [
						  'ok'      => false,
						  'title'   => $host['title'],
						  'message' => "Connection failed. Status '$response_code'. Please ensure PHP is allowed to connect to the host '" . $host['hostname'] . "' - or ask your hosting provider to do this if you’re unsure. " . ( is_wp_error( $response ) ? $response->get_error_message() : '' ),
					  ];
				  }
			  } catch ( \Exception $e ) {
				  $limits[ $host['hostname'] ] = [
					  'ok'      => true,
					  'title'   => $host['title'],
					  'message' => "Connection failed. Please contact the hosting provider and ensure PHP is allowed to connect to the host '" . $host['hostname'] . "'. " . $e->getMessage(),
				  ];
			  }
		  }


		  // Check authenticated API request
			if ( !defined('CODALIX_LOCAL_DEVELOPMENT') ) {
				$response = codalix_market()->api()->request( 'https://api.codalixmarket.cloud/whoami' );

				if ( is_wp_error( $response ) ) {
					$limits['authentication'] = [
						'ok'      => false,
						'title'   => 'Codalix API Authentication',
						'message' => "Not currently authenticated with the Codalix API. Please add your API token. " . $response->get_error_message(),
					];
				} elseif ( ! isset( $response['scopes'] ) ) {
					$limits['authentication'] = [
						'ok'      => false,
						'title'   => 'Codalix API Authentication',
						'message' => "Missing API permissions. Please re-create your Codalix API token with the correct permissions. ",
					];
				} else {
					$minimum_scopes    = $this->get_required_permissions();
					$maximum_scopes    = array( 'default' => 'Default' ) + $minimum_scopes;
					$missing_scopes    = array();
					$additional_scopes = array();
					foreach ( $minimum_scopes as $required_scope => $required_scope_name ) {
						if ( ! in_array( $required_scope, $response['scopes'] ) ) {
							// The scope minimum required scope doesn't exist.
							$missing_scopes [] = $required_scope;
						}
					}
					foreach ( $response['scopes'] as $scope ) {
						if ( ! isset( $maximum_scopes[ $scope ] ) ) {
							// The available scope is outside our maximum bounds.
							$additional_scopes [] = $scope;
						}
					}
					$limits['authentication'] = [
						'ok'      => true,
						'title'   => 'Codalix API Authentication',
						'message' => "Authenticated successfully with correct scopes: " . implode( ', ', $response['scopes'] ),
					];
				}
			}

		  $debug_enabled      = defined( 'WP_DEBUG' ) && WP_DEBUG;
		  $limits['wp_debug'] = [
			  'ok'      => ! $debug_enabled,
			  'title'   => 'WP Debug',
			  'message' => $debug_enabled ? 'If you’re on a production website, it’s best to set WP_DEBUG to false, please ask your hosting provider to do this if you’re unsure.' : 'WP Debug is disabled, all ok.',
		  ];

		  $zip_archive_installed = class_exists( '\ZipArchive' );
		  $limits['zip_archive'] = [
			  'ok'      => $zip_archive_installed,
			  'title'   => 'ZipArchive Support',
			  'message' => $zip_archive_installed ? 'ZipArchive is available.' : 'ZipArchive is not available. If you have issues installing or updating items please ask your hosting provider to enable ZipArchive.',
		  ];


		  $php_version_ok        = version_compare( PHP_VERSION, '7.0', '>=' );
		  $limits['php_version'] = [
			  'ok'      => $php_version_ok,
			  'title'   => 'PHP Version',
			  'message' => $php_version_ok ? 'PHP version is ok at ' . PHP_VERSION . '.' : 'Please ask the hosting provider to upgrade your PHP version to at least 7.0 or above.',
		  ];

		  require_once( ABSPATH . 'wp-admin/includes/file.php' );
		  $current_filesystem_method = get_filesystem_method();
		  if ( $current_filesystem_method !== 'direct' ) {
			  $limits['filesystem_method'] = [
				  'ok'      => false,
				  'title'   => 'WordPress Filesystem',
				  'message' => 'Please enable WordPress FS_METHOD direct - or ask your hosting provider to do this if you’re unsure.',
			  ];
		  }

		  $wp_upload_dir                 = wp_upload_dir();
		  $upload_base_dir               = $wp_upload_dir['basedir'];
		  $upload_base_dir_writable      = is_writable( $upload_base_dir );
		  $limits['wp_content_writable'] = [
			  'ok'      => $upload_base_dir_writable,
			  'title'   => 'WordPress File Permissions',
			  'message' => $upload_base_dir_writable ? 'is ok.' : 'Please set correct WordPress PHP write permissions for the wp-content directory - or ask your hosting provider to do this if you’re unsure.',
		  ];

		  $active_plugins    = get_option( 'active_plugins' );
		  $active_plugins_ok = count( $active_plugins ) < 15;
		  if ( ! $active_plugins_ok ) {
			  $limits['active_plugins'] = [
				  'ok'      => false,
				  'title'   => 'Active Plugins',
				  'message' => 'Please try to reduce the number of active plugins on your WordPress site, as this will slow things down.',
			  ];
		  }

		  return $limits;
	  }


	  /**
		 * Admin page callback.
		 *
		 * @since 1.0.0
		 */
		public function render_admin_callback() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/callback/admin.php' );
		}

		/**
		 * OAuth section callback.
		 *
		 * @since 1.0.0
		 */
		public function render_oauth_section_callback() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/callback/section/oauth.php' );
		}

		/**
		 * Items section callback.
		 *
		 * @since 1.0.0
		 */
		public function render_items_section_callback() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/callback/section/items.php' );
		}

		/**
		 * Token setting callback.
		 *
		 * @since 1.0.0
		 */
		public function render_token_setting_callback() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/callback/setting/token.php' );
		}

		/**
		 * Items setting callback.
		 *
		 * @since 1.0.0
		 */
		public function render_items_setting_callback() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/callback/setting/items.php' );
		}

		/**
		 * Intro
		 *
		 * @since 1.0.0
		 */
		public function render_intro_partial() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/partials/intro.php' );
		}

		/**
		 * Tabs
		 *
		 * @since 1.0.0
		 */
		public function render_tabs_partial() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/partials/tabs.php' );
		}

		/**
		 * Settings panel
		 *
		 * @since 1.0.0
		 */
		public function render_settings_panel_partial() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/partials/settings.php' );
		}


		/**
		 * Help panel
		 *
		 * @since 2.0.1
		 */
		public function render_help_panel_partial() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/partials/help.php' );
		}

		/**
		 * Themes panel
		 *
		 * @since 1.0.0
		 */
		public function render_themes_panel_partial() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/partials/themes.php' );
		}

		/**
		 * Plugins panel
		 *
		 * @since 1.0.0
		 */
		public function render_plugins_panel_partial() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/partials/plugins.php' );
		}

		/**
		 * Success notice.
		 *
		 * @since 1.0.0
		 */
		public function render_success_notice() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/notice/success.php' );
		}

		/**
		 * Success no-items notice.
		 *
		 * @since 1.0.0
		 */
		public function render_success_no_items_notice() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/notice/success-no-items.php' );
		}

		/**
		 * Success single-use notice.
		 *
		 * @since 1.0.0
		 */
		public function render_success_single_use_notice() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/notice/success-single-use.php' );
		}

		/**
		 * Error details.
		 *
		 * @since 2.0.2
		 */
		public function render_additional_error_details() {
			$error_details = get_site_transient( codalix_market()->get_option_name() . '_error_information' );
			if ( $error_details && ! empty( $error_details['title'] ) ) {
				extract( $error_details );
				require( codalix_market()->get_plugin_path() . 'inc/admin/view/notice/error-details.php' );
			}
		}

		/**
		 * Error notice.
		 *
		 * @since 1.0.0
		 */
		public function render_error_notice() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/notice/error.php' );
			$this->render_additional_error_details();
		}

		/**
		 * Permission error notice.
		 *
		 * @since 2.0.1
		 */
		public function render_error_permissions() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/notice/error-permissions.php' );
			$this->render_additional_error_details();
		}

		/**
		 * Error single-use notice.
		 *
		 * @since 1.0.0
		 */
		public function render_error_single_use_notice() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/notice/error-single-use.php' );
			$this->render_additional_error_details();
		}

		/**
		 * Error missing zip.
		 *
		 * @since 2.0.1
		 */
		public function render_error_missing_zip() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/notice/error-missing-zip.php' );
			$this->render_additional_error_details();
		}

		/**
		 * Error http
		 *
		 * @since 2.0.1
		 */
		public function render_error_http() {
			require( codalix_market()->get_plugin_path() . 'inc/admin/view/notice/error-http.php' );
			$this->render_additional_error_details();
		}

		/**
		 * Use the Settings API when in network mode.
		 *
		 * This allows us to make use of the same WordPress Settings API when displaying the menu item in network mode.
		 *
		 * @since 2.0.0
		 */
		public function save_network_settings() {
			check_admin_referer( codalix_market()->get_slug() . '-options' );

			global $new_whitelist_options;
			$options = $new_whitelist_options[ codalix_market()->get_slug() ];

			foreach ( $options as $option ) {
				if ( isset( $_POST[ $option ] ) ) {
					update_site_option( $option, $_POST[ $option ] );
				} else {
					delete_site_option( $option );
				}
			}
			wp_redirect( codalix_market()->get_page_url() );
			exit;
		}

		/**
		 * Store additional error information in transient so users can self debug.
		 *
		 * @since 2.0.2
		 */
		public function store_additional_error_debug_information( $title, $message = '', $data = [] ) {
			set_site_transient(
				codalix_market()->get_option_name() . '_error_information',
				[
					'title'   => $title,
					'message' => $message,
					'data'    => $data,
				],
				120
			);
		}
	}

endif;






