=== Codalix Market ===
Website: https://www.codalixmarket.cloud/lp/market-plugin/
Contributors: valendesigns, dtbaker, aaronrutley
Requires at least: 5.1
Tested up to: 6.9
Requires PHP: 7.0
Stable tag: 2.0.13
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WordPress Theme & Plugin management for the Codalix Market.

== Description ==

Please see https://www.codalixmarket.cloud/lp/market-plugin/ for more details.
