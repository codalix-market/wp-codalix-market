<?php
/**
 * Plugin Name: Codalix Market
 * Plugin URI: https://codalixmarket.cloud/market-plugin/
 * Description: WordPress Theme & Plugin management for the Codalix Market.
 * Version: 2.0.13
 * Author: Codalix
 * Author URI: https://codalixmarket.cloud
 * Requires at least: 5.1
 * Tested up to: 6.9
 * Requires PHP: 7.0
 * Text Domain: codalix-market
 * Domain Path: /languages/
 *
 * @package Codalix_Market
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/* Set plugin version constant. */
define( 'CODALIX_MARKET_VERSION', '2.0.13' );

/* Debug output control. */
define( 'CODALIX_MARKET_DEBUG_OUTPUT', 0 );

/* Set constant path to the plugin directory. */
define( 'CODALIX_MARKET_SLUG', basename( plugin_dir_path( __FILE__ ) ) );

/* Set constant path to the main file for activation call */
define( 'CODALIX_MARKET_CORE_FILE', __FILE__ );

/* Set constant path to the plugin directory. */
define( 'CODALIX_MARKET_PATH', trailingslashit( plugin_dir_path( __FILE__ ) ) );

/* Set the constant path to the plugin directory URI. */
define( 'CODALIX_MARKET_URI', trailingslashit( plugin_dir_url( __FILE__ ) ) );

if ( ! version_compare( PHP_VERSION, '7.0', '>=' ) ) {
	add_action( 'admin_notices', 'codalix_market_fail_php_version' );
} elseif ( CODALIX_MARKET_SLUG !== 'codalix-market' ) {
	add_action( 'admin_notices', 'codalix_market_fail_installation_method' );
} else {

	// Show deprecation notice for PHP versions below 8.2
	if ( version_compare( PHP_VERSION, '8.2', '<' ) ) {
		add_action( 'admin_notices', 'codalix_market_php_deprecation_notice' );
	}

	if ( ! function_exists( 'is_plugin_active_for_network' ) ) {
		// Makes sure the plugin functions are defined before trying to use them.
		require_once( ABSPATH . '/wp-admin/includes/plugin.php' );
	}
	define( 'CODALIX_MARKET_NETWORK_ACTIVATED', is_plugin_active_for_network( CODALIX_MARKET_SLUG . '/codalix-market.php' ) );

	/* Codalix_Market Class */
	require_once CODALIX_MARKET_PATH . 'inc/class-codalix-market.php';

	if ( ! function_exists( 'codalix_market' ) ) :
		/**
		 * The main function responsible for returning the one true
		 * Codalix_Market Instance to functions everywhere.
		 *
		 * Use this function like you would a global variable, except
		 * without needing to declare the global.
		 *
		 * Example: <?php $codalix_market = codalix_market(); ?>
		 *
		 * @since 1.0.0
		 * @return Codalix_Market The one true Codalix_Market Instance
		 */
		function codalix_market() {
			return Codalix_Market::instance();
		}
	endif;


	/**
	 * Loads the main instance of Codalix_Market to prevent
	 * the need to use globals.
	 *
	 * This doesn't fire the activation hook correctly if done in 'after_setup_theme' hook.
	 *
	 * @since 1.0.0
	 * @return object Codalix_Market
	 */
	codalix_market();

}

if ( ! function_exists( 'codalix_market_fail_php_version' ) ) {

	/**
	 * Show in WP Dashboard notice about the plugin is not activated.
	 *
	 * @since 2.0.0
	 *
	 * @return void
	 */
	function codalix_market_fail_php_version() {
		$message      = esc_html__( 'The Codalix Market plugin requires PHP version 7.0+, plugin is currently NOT ACTIVE. Please contact the hosting provider to upgrade the version of PHP.', 'codalix-market' );
		$html_message = sprintf( '<div class="notice notice-error">%s</div>', wpautop( $message ) );
		echo wp_kses_post( $html_message );
	}
}

if ( ! function_exists( 'codalix_market_php_deprecation_notice' ) ) {

	/**
	 * Show deprecation notice for PHP versions below 8.2.
	 *
	 * @since 2.0.13
	 *
	 * @return void
	 */
	function codalix_market_php_deprecation_notice() {
		// Only show to users who can update plugins
		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		$php_version = PHP_VERSION;
		$message     = sprintf(
			/* translators: %s: Current PHP version */
			esc_html__( 'Codalix Market: Your site is running PHP %s, which has reached end-of-life and no longer receives security updates. Please upgrade to PHP 8.2 or higher. Support for PHP versions below 8.2 will be removed in June 2026.', 'codalix-market' ),
			$php_version
		);
		$html_message = sprintf( '<div class="notice notice-warning is-dismissible"><p><strong>%s</strong></p></div>', $message );
		echo wp_kses_post( $html_message );
	}
}



if ( ! function_exists( 'codalix_market_fail_installation_method' ) ) {

	/**
	 * The plugin needs to be installed into the `codalix-market/` folder otherwise it will not work correctly.
	 * This alert will display if someone has installed it into the incorrect folder (i.e. github download zip).
	 *
	 * @since 2.0.0
	 *
	 * @return void
	 */
	function codalix_market_fail_installation_method() {
		$message      = sprintf( esc_html__( 'Codalix Market plugin is not installed correctly. Please delete this plugin and get the correct zip file from %s.', 'codalix-market' ), '<a href="https://codalixmarket.cloud/market-plugin/" target="_blank">https://codalixmarket.cloud/market-plugin/</a>' );
		$html_message = sprintf( '<div class="notice notice-error">%s</div>', wpautop( $message ) );
		echo wp_kses_post( $html_message );
	}
}


